#define _GNU_SOURCE
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <dlfcn.h>

char *table[20];
int idx = 0;

void alloc();
void delete();
void check();
void view();
void hidden();

void alloc(){
    unsigned long size;
    printf("Index: ");
    scanf("%d",&idx);
    if(idx <= 10){
        printf("size: ");
        scanf("%ld",&size);
        table[idx] = (char *)malloc(size);
        printf("Data: ");
        getchar();
        fgets(table[idx],size,stdin);
    }else{
        printf("Erorr The Index is greater than 10");
    }
}


void delete(){  
    printf("Index: ");
    scanf("%d",&idx);
    free(table[idx]);
}


int main(){
    setvbuf(stdout, 0, 2, 0);
	setvbuf(stdin, 0, 2, 0);
    printf("printf: %p\n",printf);
    while(1){
    int choice;
    printf("\n1- Alloc\n2- Free\n> ");
    scanf("%d",&choice);
    switch (choice){
        case 1:
            alloc();
            break;
        case 2:
            delete();
            break;

        default:
            printf("Invaild Choice\n");

    }

}}