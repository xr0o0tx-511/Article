#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

int check_of_chunk[5] = {0};
char *table[5];

void alloc();
void edit();
void delete();
void check();

int idx = 0;
int i;
int number_of_tables = {0};
unsigned long size;

void alloc(){    
    if(number_of_tables <= 5){
        for(i = 0;i< 5;i++){
            if(!check_of_chunk[i]){
                printf("size: ");
                scanf("%ld",&size);
                if(size <= 0x78 || size >= 0x3E8){
                printf("Only Smallbins\n");
                break;
                }else{
                    table[i] = (char *)malloc(size);
                    check_of_chunk[i] = 1;
                    number_of_tables++;
                    printf("Created Chunk at index %d\n",i);
                    break;
        }
    }
    }
}else{
        printf("Erorr The Index is greater than 5");
    }
}

void delete(){  
    printf("Index: ");
    scanf("%d",&idx);
    if(idx >= 5){
        printf("Invaild Index\n");
    }
    else if(check_of_chunk[idx]){
        free(table[idx]);
        table[idx] = NULL;
    }else{
        printf("This Chunk is Already Freed\n");
    }
}

void edit(){
    printf("Index: ");
    scanf("%d",&idx);
    if(idx >= 5){
        printf("Invaild Index\n");
    }
    else{
        printf("Data: ");
        getchar();
        fgets(table[idx],size+8,stdin);
    }
}


int main(){
    setvbuf(stdout, 0, 2, 0);
	setvbuf(stdin, 0, 2, 0);
    printf("printf: %p\n",printf);
    while(1){
    int choice;
    printf("\n1- Alloc\n2- Edit\n3- Free\n\n> ");
    scanf("%d",&choice);
    switch (choice){
        case 1:
            alloc();
            break;
        case 2:
            edit();
            break;
        case 3:
            delete();
            break;
        default:
            printf("Invaild Choice\n");

    }

}}