#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

typedef struct{ 
    char name[8];
    char *ptr;
} chunk;


int get_int();

int size_of_table[20] = {0};
chunk table[20];

int main(){
    setvbuf(stdout, 0, 2, 0);
	setvbuf(stdin, 0, 2, 0);
    printf("printf: %p\n",printf);
    char *ptr = (char *)malloc(0x88);
    printf("heap: %p\n",ptr-16);
    free(ptr);
    int idx = 0;
    size_t size;
    int number_of_tables = 0;
    int check_of_chunk[20] = {0};
    memset(table,0,sizeof(table));
    while(1){
    int choice;
    int i;
    printf("\n1- Alloc\n2- Free\n> ");
    choice = get_int();
    switch (choice){
        case 1:
            printf("Size: ");
            scanf("%ld",&size);
            if(number_of_tables <= 20){
                for(i = 0;i < 20;i++){
                    if(!table[i].ptr){
                        size_of_table[i] = size;
                        table[i].ptr = (char *)malloc(size);
                        check_of_chunk[i] = 1;
                        printf("Data: ");
                        read(0,table[i].ptr,size_of_table[i]);
                        printf("Chunk Name: ");
                        read(0,table[i].name,0x10);
                        printf("Created Chunk at index %d\n",i);
                        ++number_of_tables;
                        break;
                    }
                }
            
            }
            break;
        case 2:
            printf("Index: ");
            scanf("%d",&idx);
            if(check_of_chunk[idx]){
                free(table[idx].ptr);
                check_of_chunk[idx] = 0;
            }else{
                printf("Not Found This Chunk\n");
            }
            break;

        default:
            printf("Invaild Choice\n");

    }
}
    return 0;
}

int get_int(){
    char num[10];
    int res;
    read(0,num,10);
    res = atoi(num);
    return res;
}